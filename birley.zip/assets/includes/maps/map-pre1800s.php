<div class="map__inner map__inner--pre">

  <div class="icon icon__farm">
    <div class="icon__farm--hover">
      <p>The site of Jackson’s Farm lies within the present Birley boundaries, and is shown on an OS map of 1848 when it comprised a farmhouse and two further buildings to the north. It is not known when the farm was first established, but potentially the site might be of medieval origin.</p>
    </div>
  </div>


</div>
