<footer class="main-footer">
  <div class="main-footer__item">
    <p><a href="http://www.mmu.ac.uk/legal/#copy">&copy; 2017 Manchester Metropolitan University</a></p>
    <p><a href="http://www.mmu.ac.uk/web/feedback/">Feedback</a><p>
  </div>
  <div class="main-footer__item">
    <p><a href="<?php echo $linkHome?>about.php">About</a></p>
    <p><a href="<?php echo $linkHome?>contact.php">Contact</a></p>
</div>
</footer>
